package basic02;

public interface MessageBean {
	public void sayHello(String name);
	
}
