package basic01;

public class App {
    public static void main( String[] args ){
    	MessageBean bean = new MessageBean();
    	bean.sayHello("연두부");
    }
}
