package basic03;

public interface MessageBean {
	public void sayHello(String name);
	
}
